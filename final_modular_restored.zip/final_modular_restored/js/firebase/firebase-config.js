


        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
        import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-analytics.js";
        import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-database.js";

        const firebaseConfig = {
            apiKey: "AIzaSyDI7PWtKHqwTYooaOYJM-WM7fC8nrFNxvg",
            authDomain: "allahardaan-business-solution.firebaseapp.com",
            databaseURL: "https://allahardaan-business-solution-default-rtdb.firebaseio.com",
            projectId: "allahardaan-business-solution",
            storageBucket: "allahardaan-business-solution.firebasestorage.app",
            messagingSenderId: "264163019914",
            appId: "1:264163019914:web:4a65f4d956b1ad35ebf173",
            measurementId: "G-YR2PS5QTJ2"
        };

        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
        const db = getDatabase(app);
        const connectedRef = ref(db, ".info/connected");

        console.log("Firebase Connected Successfully");
        
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');

        onValue(connectedRef, (snap) => {
            if (snap.val() === true) {
                statusText.innerText = "Online";
                statusText.className = "text-green-300";
                statusDot.className = "w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_6px_#4ade80]";
            } else {
                statusText.innerText = "Offline";
                statusText.className = "text-red-300";
                statusDot.className = "w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_6px_#ef4444]";
            }
        });
    


        // =========================
        // CORE APP FOUNDATION
        // =========================

        // Global App State
        const appData = {
            products: [],
            customers: [],
            suppliers: [],
            sales: [],
            purchases: [],
            expenses: [],
            settings: {}
        };

        // Unique ID Generator
        function generateId(prefix) {
            return prefix + "_" + Date.now();
        }

        // Firebase Base Functions
        async function saveData(path, data) {
            try {
                console.log("Save Data:", path, data);
            } catch (error) {
                console.error(error);
            }
        }

        async function getData(path) {
            try {
                console.log("Get Data:", path);
            } catch (error) {
                console.error(error);
            }
        }

        async function updateData(path, data) {
            try {
                console.log("Update Data:", path, data);
            } catch (error) {
                console.error(error);
            }
        }

        async function deleteData(path) {
            try {
                console.log("Delete Data:", path);
            } catch (error) {
                console.error(error);
            }
        }

        // Navigation Controller
        function openPage(pageId) {
            hideAllPages();

            const targetPage = document.getElementById(pageId);

            if(targetPage) {
                if(pageId === 'dashboardScreen') {
                    targetPage.classList.replace('hidden', 'block');
                } else {
                    targetPage.classList.remove('hidden');
                }

                history.pushState({ activeId: pageId }, "");
            }
        }

        function closePage() {
            history.back();
        }

        // Local Cache Layer
        function saveLocalCache(key, data) {
            localStorage.setItem(key, JSON.stringify(data));
        }

        function getLocalCache(key) {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        }

        console.log("Core Foundation Ready");
    


// =========================
// SYSTEM OPTIMIZATION LAYER
// =========================

// Global Error Handler
window.addEventListener('error', function(event) {
    console.error('System Error:', event.message);
});

// Async Loading Controller
function showLoading() {
    let loader = document.getElementById('globalLoader');
    if(loader) loader.classList.remove('hidden');
}

function hideLoading() {
    let loader = document.getElementById('globalLoader');
    if(loader) loader.classList.add('hidden');
}

// Safe Input Validation
function validateText(value) {
    return value && value.trim().length > 0;
}

function validatePhone(phone) {
    return /^01[3-9]\d{8}$/.test(phone);
}

function validateAmount(amount) {
    return !isNaN(amount) && Number(amount) >= 0;
}

// Dynamic Search Engine
document.addEventListener('input', function(e) {
    if(e.target.placeholder === "Search customer/supplier...") {
        const value = e.target.value.toLowerCase();
        console.log("Searching:", value);
    }
});

// Firebase Safe Wrapper
async function safeFirebaseOperation(callback) {
    try {
        showLoading();
        await callback();
    } catch(error) {
        console.error(error);
        alert("System Error Occurred");
    } finally {
        hideLoading();
    }
}

// Local Cache Auto Save
window.addEventListener('beforeunload', function() {
    saveLocalCache('app_backup', appData);
});

// Restore Local Cache
window.addEventListener('load', function() {
    const cache = getLocalCache('app_backup');

    if(cache) {
        Object.assign(appData, cache);
        console.log("Local Cache Restored");
    }
});

// Dynamic Statistics Placeholder
function updateDashboardStats() {
    console.log("Dashboard Stats Updating...");
}

// Realtime Data Refresh Placeholder
function refreshRealtimeData() {
    console.log("Realtime Sync Ready");
}

// Modular Sections Ready
const modules = {
    products: {},
    customers: {},
    sales: {},
    purchases: {},
    reports: {},
    settings: {}
};

console.log("Optimization Layer Activated");
