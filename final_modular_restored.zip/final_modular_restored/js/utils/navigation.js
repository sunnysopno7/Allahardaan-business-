
export function hideAllPages() {

    document.querySelectorAll('[id$="Page"], .page, #dashboardScreen')
    .forEach(page => page.classList.add('hidden'));

}

export function showPage(id) {

    hideAllPages();

    const target = document.getElementById(id);

    if(target){
        target.classList.remove('hidden');
    }

}
