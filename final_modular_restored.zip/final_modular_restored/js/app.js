
import './firebase/firebase-config.js';

import './pages/dashboard.js';
import './pages/settings.js';
import './pages/business-card.js';
import './pages/khata.js';

import './services/app-services.js';

console.log('Final Modular Restored Build Loaded');
