// Modular Extracted Logic

        var khataPage = document.getElementById('khataPage');
                    'khataPage': khataPage,
            khataPage.classList.add('hidden');
        function updateKhataPageTitle() {
            var khataTitleElem = document.getElementById('khataPageTitle');
                    khataTitleElem.innerText = "আমার দোকান";
                    khataTitleElem.innerText = "My Shop";
                khataTitleElem.innerText = bName;
        function openKhataPage() {
            updateKhataPageTitle();
            navigateTo(khataPage, 'khataPage');
        function closeKhataPage() {
            updateKhataPageTitle();
            updateKhataPageTitle();
        updateKhataPageTitle();
