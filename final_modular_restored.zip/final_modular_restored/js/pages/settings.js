// Modular Extracted Logic

        var languagePage = document.getElementById('languagePage');
        var currencyPage = document.getElementById('currencyPage');
                    'languagePage': languagePage,
                    'currencyPage': currencyPage,
            languagePage.classList.add('hidden');
            currencyPage.classList.add('hidden');
            var selectedLanguage = document.querySelector('input[name="systemLanguage"]:checked') ? document.querySelector('input[name="systemLanguage"]:checked').value : 'en';
                if(selectedLanguage === 'bn') {
        function openLanguagePage() {
            navigateTo(languagePage, 'languagePage');
        function closeLanguagePage() {
        function openCurrencyPage() {
            navigateTo(currencyPage, 'currencyPage');
        function closeCurrencyPage() {
        function saveLanguageConfig() {
            var selectedLanguage = document.querySelector('input[name="systemLanguage"]:checked').value;
            var languageNodes = document.querySelectorAll('.data-lang');
            languageNodes.forEach(function(node) {
                if (selectedLanguage === 'bn') { 
            closeLanguagePage();
            var input = document.getElementById('currencySearchInput');
            var items = document.querySelectorAll('.currency-item');
        function saveCurrencyConfig() {
            var selectedCurrency = document.querySelector('input[name="systemCurrency"]:checked').value;
            var symbols = document.querySelectorAll('.currency-symbol');
            symbols.forEach(function(el) { el.innerText = selectedCurrency; });
            closeCurrencyPage();
