// Modular Extracted Logic

        var profileSettingsPage = document.getElementById('profileSettingsPage');
        var businessCardPage = document.getElementById('businessCardPage');
        var currentSelectedCardId = 1; 
                    'profileSettingsPage': profileSettingsPage,
                    'businessCardPage': businessCardPage,
            profileSettingsPage.classList.add('hidden');
            businessCardPage.classList.add('hidden');
        function openProfileSettings() {
            navigateTo(profileSettingsPage, 'profileSettingsPage');
        function closeProfileSettings() {
        function openBusinessCardPage() {
            businessCardPage.classList.remove('hidden');
            history.pushState({ activeId: 'businessCardPage' }, "");
            syncProfileToCard();
        function closeBusinessCardPage() {
        function syncProfileToCard() {
            document.getElementById('cardBizName1').innerText = bName;
            document.getElementById('cardService1').innerText = srv;
            document.getElementById('cardOwnerName1').innerHTML = '<i class="fa-solid fa-user text-[9px] mr-1.5 text-yellow-300"></i>' + oName;
            document.getElementById('cardAddress1').innerHTML = '<i class="fa-solid fa-location-dot text-[9px] mr-1.5 text-yellow-300"></i>' + addr;
            document.getElementById('cardMobile1').innerHTML = '<i class="fa-solid fa-phone text-[8px] mr-1"></i>' + mob;
            document.getElementById('cardBizName2').innerText = bName;
            document.getElementById('cardService2').innerText = srv;
            document.getElementById('cardOwnerName2').innerText = oName;
            document.getElementById('cardAddress2').innerText = addr;
            document.getElementById('cardMobile2').innerText = mob;
        function selectCardDesign(id) {
            currentSelectedCardId = id; 
                document.getElementById('cardDesign1').className = "bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white p-5 rounded-2xl shadow-xl relative cursor-pointer active:scale-[0.99] transition-all duration-300 h-44 flex flex-col justify-between overflow-hidden border-2 border-blue-500/80";
                document.getElementById('cardDesign2').className = "bg-slate-900 text-gray-100 p-5 rounded-2xl shadow-xl relative cursor-pointer active:scale-[0.99] transition-all duration-300 h-44 flex flex-col justify-between overflow-hidden border-2 border-transparent";
                document.getElementById('cardDesign1').className = "bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white p-5 rounded-2xl shadow-xl relative cursor-pointer active:scale-[0.99] transition-all duration-300 h-44 flex flex-col justify-between overflow-hidden border-2 border-transparent";
                document.getElementById('cardDesign2').className = "bg-slate-900 text-gray-100 p-5 rounded-2xl shadow-xl relative cursor-pointer active:scale-[0.99] transition-all duration-300 h-44 flex flex-col justify-between overflow-hidden border-2 border-blue-500/80";
            alert("Card Design Template " + id + " Selected!");
            var cardElement = document.getElementById('cardDesign' + currentSelectedCardId);
                html2canvas(cardElement, renderOptions).then(function(canvas) {
                        downloadLink.download = 'Premium_Business_Card_' + bName.replace(/\s+/g, '_') + '.png';
                        pdf.save('Premium_Business_Card_' + bName.replace(/\s+/g, '_') + '.pdf');
                html2canvas(cardElement, renderOptions).then(async function(canvas) {
                        var file = new File([blob], 'Business_Card.png', { type: 'image/png' });
        function saveBusinessCardConfig() {
            syncProfileToCard();
            alert("Business Card Preferences Saved Successfully!");
            closeBusinessCardPage();
        function updateProfileData() {
            syncProfileToCard();
            alert("Profile metadata updated successfully!");
            closeProfileSettings();
