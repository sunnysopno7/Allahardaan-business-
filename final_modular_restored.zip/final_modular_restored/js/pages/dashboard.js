// Modular Extracted Logic

        var dashboardScreen = document.getElementById('dashboardScreen');
                    'dashboardScreen': dashboardScreen,
                    if(event.state.activeId === 'dashboardScreen') {
                dashboardScreen.classList.replace('hidden', 'block');
            dashboardScreen.classList.replace('block', 'hidden');
            if(pageId === 'dashboardScreen') {
                        text: 'Shared business image node from dashboard.'
        history.replaceState({ activeId: 'dashboardScreen' }, "");
