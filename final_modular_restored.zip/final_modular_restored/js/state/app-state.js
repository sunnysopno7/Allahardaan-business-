
export const appState = {

    language: 'bn',
    currency: '৳',
    activePage: 'dashboard',

};
